package com.example.AlquilerBicicletas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlquilerBicicletasApplicationTests {

	@Test
	void contextLoads() {
	}

}
